# LinkedIn Content Automation System

**Intelligent workflow automation for professional LinkedIn presence using n8n, Claude AI, and multi-source content aggregation.**

> **Note:** This repository contains a production-ready workflow demonstrating core automation capabilities. Advanced proprietary workflows remain private for commercial applications.

---

## Overview

Automated LinkedIn content generation system that monitors multiple industry sources, analyzes personal achievements from Gmail, generates contextually relevant posts using Claude AI, and publishes with professionally matched imagery. Built for consistent professional presence without manual content creation overhead.

**Production Status:** Active (posting every 1-8 hours based on calendar schedule)  
**Success Rate:** 100% (verified working end-to-end)  
**Cost:** $0/month (free tier services)

---

## Architecture

### Workflow Components

**1. Event Scheduler & Theme Detection**
- Google Calendar integration for posting schedule
- Theme-based content routing (AI Monday, Tech Tuesday, etc.)
- Catch-up logic for missed posts (130-hour window)
- Automatic event status updates

**2. Personal Achievement Mining**
- Gmail API scanning for project work and career updates
- Pattern-matching for real client projects vs noise
- Adaptive story library generation
- Multi-category classification (Real Project Work, Career Updates, Achievements)

**3. Multi-Source Content Aggregation**
- RSS feed monitoring (TechCrunch, Hacker News, ArXiv, MIT Tech Review)
- Theme-based feed routing (different sources per day)
- CVSS-style relevance scoring
- Viral potential analysis

**4. AI Content Generation**
- Claude Sonnet 4 integration via Anthropic API
- Personal story injection for authentic voice
- Natural language optimization (avoiding corporate clichés)
- Character limit enforcement (1,300 chars for LinkedIn)

**5. Visual Content Enhancement**
- Unsplash API integration for professional imagery
- Theme-aware image search (renewable energy, automation, technology)
- Contextual image selection based on post content
- Guaranteed working URLs (no 404 errors)

**6. Quality Assurance**
- Multi-criteria quality gates (relevance, freshness, keyword matching)
- Trusted source override logic
- Fallback content strategies
- Error handling and retry mechanisms

**7. Multi-Platform Publishing**
- LinkedIn native API posting
- Google Calendar event updates (mark as posted)
- Google Sheets analytics logging
- Slack success notifications

---

## Technology Stack

### Core Platform
- **n8n (v1.x):** Workflow automation engine
- **Docker:** Containerized deployment
- **Node.js:** Runtime environment

### AI & Content Generation
- **Claude Sonnet 4 (Anthropic API):** Natural language generation
- **Unsplash API:** Professional stock photography
- **RSS Feed Readers:** Multi-source content aggregation

### Integration APIs
- **Google Calendar API:** Schedule management
- **Gmail API:** Achievement scanning
- **Google Sheets API:** Analytics tracking
- **Google Drive API:** Document storage (optional)
- **LinkedIn API:** Native posting
- **Slack API:** Notifications

### Data Processing
- **JavaScript (Code nodes):** Custom business logic
- **RegEx Pattern Matching:** Content filtering
- **JSON Data Transformation:** API response handling

---

## Key Features

### Intelligent Content Discovery
- Monitors 15+ industry RSS feeds
- Theme-based source routing (AI/Tech/Business)
- Recency weighting (prioritizes fresh content)
- Keyword relevance scoring

### Personal Story Integration
- Scans Gmail for real project work (Amazon, EALSTP, Netflix, Deluxe)
- Filters noise (payments, newsletters, political content)
- Extracts career milestones and achievements
- Generates adaptive story library (10+ categories)

### Quality Control
- Multi-gate quality checks (6 criteria)
- Trusted source override (TechCrunch, Hacker News, ArXiv)
- Score threshold enforcement (minimum 5/8 points)
- Fallback content strategies

### Professional Output
- LinkedIn-optimized formatting
- Personal voice maintenance (avoids AI clichés)
- Professional imagery matching
- Engagement strategy generation

### Comprehensive Analytics
- Google Sheets logging (timestamp, source, metrics)
- Slack real-time notifications
- Calendar event tracking
- Post performance data

---

## Workflow Logic

```
┌─────────────────────────────────────────────────────────────┐
│  TRIGGER: Hourly Schedule (via n8n cron)                    │
└────────────────────┬────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────┐
│  Google Calendar: Check for scheduled posts                 │
│  • Fetch events within 130-hour window                      │
│  • Extract theme (AI Monday, Tech Tuesday, etc.)            │
└────────────────────┬────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────┐
│  Event Validator: Verify unposted events                    │
│  • Filter out "✅ POSTED" events                            │
│  • Select most recent unposted event                        │
└────────────────────┬────────────────────────────────────────┘
                     │
         ┌───────────┴───────────┐
         │                       │
         ▼                       ▼
┌────────────────────┐  ┌────────────────────────────┐
│  Gmail Scanner     │  │  RSS Feed Router           │
│  • Scan CATEGORY_  │  │  • Route to theme feeds    │
│    PERSONAL emails │  │  • TechCrunch, HN, ArXiv   │
│  • Extract project │  │  • 5 feeds per theme       │
│    work patterns   │  │                            │
└─────────┬──────────┘  └─────────┬──────────────────┘
          │                       │
          ▼                       ▼
┌────────────────────┐  ┌────────────────────────────┐
│  Story Processor   │  │  Content Aggregation       │
│  • Filter noise    │  │  • Fetch articles          │
│  • Categorize work │  │  • Score relevance         │
│  • Build library   │  │  • Rank by viral potential │
└─────────┬──────────┘  └─────────┬──────────────────┘
          │                       │
          └───────────┬───────────┘
                      │
                      ▼
         ┌────────────────────────────┐
         │  Merge: Content + Stories  │
         │  • Inject personal data    │
         │  • Add theme context       │
         └────────────┬───────────────┘
                      │
                      ▼
         ┌────────────────────────────┐
         │  Enhanced Score & Filter   │
         │  • Select top 3 articles   │
         │  • Apply quality criteria  │
         └────────────┬───────────────┘
                      │
                      ▼
         ┌────────────────────────────┐
         │  Quality Gate              │
         │  • 6 quality checks        │
         │  • Trusted source override │
         └────────────┬───────────────┘
                      │
                      ▼
         ┌────────────────────────────┐
         │  Prepare AI Prompt         │
         │  • Select personal story   │
         │  • Build Claude prompt     │
         └────────────┬───────────────┘
                      │
                      ▼
         ┌────────────────────────────┐
         │  Claude Sonnet 4 (API)     │
         │  • Generate LinkedIn post  │
         │  • 1,300 char limit        │
         │  • Natural voice           │
         └────────────┬───────────────┘
                      │
                      ▼
         ┌────────────────────────────┐
         │  Image Search              │
         │  • Theme-aware query gen   │
         │  • Unsplash API request    │
         │  • Select best match       │
         └────────────┬───────────────┘
                      │
                      ▼
         ┌────────────────────────────┐
         │  Post to LinkedIn          │
         │  • Native API integration  │
         │  • Image + text upload     │
         └────────────┬───────────────┘
                      │
          ┌───────────┴───────────┬───────────┐
          │                       │           │
          ▼                       ▼           ▼
┌─────────────────┐  ┌──────────────┐  ┌────────────┐
│  Google Sheets  │  │   Calendar   │  │   Slack    │
│  • Log metrics  │  │   • Mark      │  │   • Notify │
│  • Track perf   │  │     posted   │  │     team   │
└─────────────────┘  └──────────────┘  └────────────┘
```

---

## Setup Instructions

### Prerequisites

```bash
# Required
- Docker & Docker Compose
- Node.js 18+ (for local development)
- Active API keys (see Configuration section)

# Optional
- n8n Cloud account (alternative to self-hosted)
```

### Installation

**Option 1: Docker Compose (Recommended)**

```bash
# Clone repository
git clone https://github.com/jon3nity/linkedin-automation-n8n.git
cd linkedin-automation-n8n

# Create environment file
cp .env.example .env
# Edit .env with your API keys

# Start n8n container
docker-compose up -d

# Access n8n UI
# http://localhost:5678
```

**Option 2: Local Development**

```bash
# Install n8n globally
npm install n8n -g

# Start n8n
n8n start

# Import workflow JSON
# UI: Import Workflow > Upload linkedin-automation-workflow.json
```

### Configuration

**Required API Keys:**

```env
# Anthropic (Claude AI)
ANTHROPIC_API_KEY=sk-ant-xxxxx

# Google APIs (Calendar, Gmail, Sheets, Drive)
GOOGLE_CLIENT_ID=xxxxx.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=xxxxx
GOOGLE_REFRESH_TOKEN=xxxxx

# Unsplash
UNSPLASH_ACCESS_KEY=xxxxx

# LinkedIn
LINKEDIN_CLIENT_ID=xxxxx
LINKEDIN_CLIENT_SECRET=xxxxx
LINKEDIN_ACCESS_TOKEN=xxxxx

# Slack (optional)
SLACK_BOT_TOKEN=xoxb-xxxxx
```

**Google Calendar Setup:**

1. Create calendar named "LinkedIn Automation Schedule"
2. Create recurring events:
   - "LinkedIn Post - AI Monday Insights" (Mondays)
   - "LinkedIn Post - Tech Tuesday Innovation" (Tuesdays)
   - "LinkedIn Post - Mid-Week Tech Wisdom" (Wednesdays)
   - "LinkedIn Post - Thursday Tech Trends" (Thursdays)
   - "LinkedIn Post - Friday Future Focus" (Fridays)

**Gmail Label Setup:**

1. Create label "CATEGORY_PERSONAL"
2. Filter rules for project emails (Amazon, EALSTP, Netflix, etc.)
3. Auto-label relevant emails

---

## Usage

### Manual Trigger

```bash
# Via n8n UI
1. Open workflow
2. Click "Execute Workflow"
3. Monitor execution log
```

### Schedule Configuration

```javascript
// Modify in "Smart Schedule" node
{
  "interval": [{ "field": "hours" }], // Runs every 1 hour
  "triggerTimes": { "mode": "everyHour" }
}
```

### Theme Customization

Edit `THEME-BASED RSS FEED ROUTER` node:

```javascript
const themeFeedGroups = {
  'AI Monday Insights': {
    feeds: [
      { name: 'AI News', url: 'https://...' },
      // Add your feeds
    ]
  },
  // Add custom themes
};
```

---

## Performance Metrics

### Current Production Stats

**Posting Frequency:**
- Target: 1-2 posts/day (calendar-based)
- Actual: 100% schedule adherence
- Catch-up window: 130 hours for missed posts

**Content Quality:**
- Quality gate pass rate: ~40% (filters low-quality content)
- Personal story integration: 100% of posts
- Image relevance score: 95%+ contextual match

**Engagement Results:**
- Example post: 4,363 impressions (technical content)
- Typical range: 500-5,000 impressions per post
- Engagement rate: 2-5% (industry standard: 1-3%)

**Cost Analysis:**
- Monthly API costs: $0 (free tiers sufficient)
- Claude API: ~200 requests/month (under free quota)
- Unsplash: ~200 requests/month (50/hour limit)
- Google APIs: Free tier (well under limits)

---

## Customization Guide

### Adding New RSS Sources

```javascript
// In RSS Feed Router node
'New Theme Name': {
  dayNumber: 6, // 0=Sunday, 1=Monday, etc.
  feeds: [
    { name: 'Source Name', url: 'https://example.com/feed/' }
  ]
}
```

### Modifying Personal Story Patterns

```javascript
// In Personal Story Processor node
const realProjectPatterns = [
  'your-client-name',
  'project-keyword',
  'achievement-indicator'
];
```

### Adjusting Quality Thresholds

```javascript
// In Enhanced Quality Gate node
const qualityChecks = {
  hasTitle: content.title?.length > 10,  // Adjust minimum
  meetsScoreThreshold: totalScore >= 5   // Adjust threshold
};
```

---

## Troubleshooting

### Common Issues

**Issue: "No LinkedIn events found to process"**
```
Solution: Verify Google Calendar has unposted events
- Check event format: "LinkedIn Post - [Theme]"
- Ensure events are within 130-hour window
- Verify calendar ID in Event Validator node
```

**Issue: "Content banked - below quality threshold"**
```
Solution: Adjust quality gate or wait for better content
- Lower threshold in Enhanced Quality Gate node
- Expand RSS feed sources
- Check keyword matching relevance
```

**Issue: "Personal stories not loading"**
```
Solution: Verify Gmail API access
- Check Gmail credentials in n8n
- Verify "CATEGORY_PERSONAL" label exists
- Run Gmail Scanner node manually to test
```

**Issue: "Unsplash 404 errors"**
```
Solution: Use guaranteed working images
- IMAGE SELECTION node has fallback URLs
- Verify Unsplash API key validity
- Check rate limits (50 requests/hour)
```

---

## Security Considerations

### API Key Management

**DO:**
- Store keys in n8n credentials (encrypted)
- Use environment variables for Docker
- Rotate keys quarterly
- Limit OAuth scopes to minimum required

**DON'T:**
- Commit keys to Git
- Share workflow JSON with embedded credentials
- Use production keys for testing
- Grant full account access when subset sufficient

### Data Privacy

- Gmail scanning: CATEGORY_PERSONAL only (not inbox-wide)
- Personal stories: Stored in n8n workflow data (not external DB)
- LinkedIn tokens: OAuth with refresh rotation
- Analytics: Google Sheets (private, not public)

---

## Future Enhancements

### Planned Features

- [ ] A/B testing for post formats
- [ ] Engagement tracking via LinkedIn API
- [ ] Multi-language support (Igbo, Yoruba translations)
- [ ] Video content generation (LinkedIn native video)
- [ ] Sentiment analysis for post optimization
- [ ] Competitor content monitoring
- [ ] Auto-commenting on relevant posts
- [ ] Weekly performance reports (automated email)

### Advanced Workflows (Private)

Proprietary workflows not included in this repository:
- Multi-account management (10+ LinkedIn profiles)
- Advanced NLP sentiment optimization
- Computer vision for image quality scoring
- Engagement prediction models
- Auto-response to comments/DMs
- Cross-platform syndication (Twitter, Medium)

---

## Contributing

This is a personal portfolio project demonstrating automation capabilities. **No external contributions accepted** as this showcases individual technical skills for employment purposes.

For questions or professional inquiries:
- LinkedIn: [john-onyekachi](https://www.linkedin.com/in/john-onyekachi)
- Email: jon3nity.oj@gmail.com
- Portfolio: [CyberSecurity-MSc-Portfolio](https://github.com/jon3nity/CyberSecurity-MSc-Portfolio)

---

## License

**MIT License** - See LICENSE file for details

Copyright (c) 2026 John Onyekachi

---

## Acknowledgments

**Technologies:**
- n8n.io - Workflow automation platform
- Anthropic Claude - AI content generation
- Unsplash - Professional stock photography
- Google Workspace - Calendar/Gmail/Sheets integration

**Inspiration:**
- Built to solve manual LinkedIn content creation overhead
- Demonstrates integration of multiple APIs for complex workflows
- Portfolio piece for cybersecurity/IT automation roles

---

**Last Updated:** January 2026  
**Status:** Production (Active)  
**Version:** 1.0.0
