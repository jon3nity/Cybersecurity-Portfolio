# Quick Setup Guide

**Get your LinkedIn automation running in 15 minutes.**

---

## Step 1: Clone Repository

```bash
git clone https://github.com/jon3nity/linkedin-automation-n8n.git
cd linkedin-automation-n8n
```

---

## Step 2: Configure Environment

```bash
# Copy environment template
cp .env.example .env

# Edit with your API keys
nano .env  # or use your preferred editor
```

**Required API Keys:**
- Anthropic Claude: https://console.anthropic.com/
- Unsplash: https://unsplash.com/oauth/applications
- Google OAuth: https://console.cloud.google.com/
- LinkedIn: https://www.linkedin.com/developers/
- Slack (optional): https://api.slack.com/apps

---

## Step 3: Start Docker Container

```bash
# Start n8n
docker-compose up -d

# Check logs
docker-compose logs -f n8n
```

**Access n8n UI:** http://localhost:5678

---

## Step 4: Import Workflow

1. **Login to n8n** (use credentials from .env)
2. **Import workflow:**
   - Click "Workflows" → "Import from File"
   - Select `linkedin-automation-workflow.json`
3. **Configure credentials:**
   - Each node with red exclamation mark needs credentials
   - Click node → "Credentials" → "Create New"
   - Follow OAuth flow for Google/LinkedIn

---

## Step 5: Setup Google Calendar

**Create Calendar:**
1. Go to Google Calendar
2. Create "LinkedIn Automation Schedule"
3. Copy calendar ID (Settings → Calendar Settings → Calendar ID)

**Create Events:**
```
Monday:    "LinkedIn Post - AI Monday Insights" (Recurring)
Tuesday:   "LinkedIn Post - Tech Tuesday Innovation" (Recurring)
Wednesday: "LinkedIn Post - Mid-Week Tech Wisdom" (Recurring)
Thursday:  "LinkedIn Post - Thursday Tech Trends" (Recurring)
Friday:    "LinkedIn Post - Friday Future Focus" (Recurring)
```

**Update Calendar ID in workflow:**
- Open "Google Calendar" node
- Paste your calendar ID
- Same for "Calendar Success Updater" node

---

## Step 6: Setup Gmail Label

1. **Create label:** "CATEGORY_PERSONAL"
2. **Create filter:**
   - From: Your work emails (Amazon, clients, etc.)
   - Action: Apply label "CATEGORY_PERSONAL"

---

## Step 7: Test Run

```bash
# Manual test
1. Open workflow in n8n
2. Click "Execute Workflow"
3. Monitor execution log
4. Check LinkedIn for post
```

**Troubleshooting:**
- Red nodes = credential issues
- Orange warnings = optional failures (e.g., Slack if not configured)
- Green = success

---

## Step 8: Enable Automation

**Activate workflow:**
1. Click toggle switch at top
2. Workflow now runs every hour
3. Checks calendar for scheduled posts
4. Posts automatically when event found

---

## Common Issues

### "No LinkedIn events found"
**Fix:** Verify calendar events exist and aren't already marked "✅ POSTED"

### "Personal stories not loading"
**Fix:** 
- Check Gmail credentials
- Verify "CATEGORY_PERSONAL" label exists
- Run Gmail Scanner node manually

### "Unsplash 404 errors"
**Fix:** Workflow has fallback images, but verify API key is valid

### "Content banked - below quality threshold"
**Fix:** Lower threshold in "Enhanced Quality Gate" node or wait for better content

---

## Production Checklist

- [ ] All API keys configured in .env
- [ ] Docker container running (`docker ps`)
- [ ] n8n UI accessible (http://localhost:5678)
- [ ] Workflow imported and activated
- [ ] Google Calendar setup with recurring events
- [ ] Gmail label "CATEGORY_PERSONAL" created
- [ ] Test execution successful
- [ ] First automated post confirmed on LinkedIn

---

## Security Reminders

- **Never commit .env file to Git**
- **Use strong n8n password**
- **Limit OAuth scopes to minimum required**
- **Rotate API keys quarterly**
- **Use separate Google account for automation (optional but recommended)**

---

## Next Steps

- Monitor Google Sheets for analytics
- Check Slack for success notifications
- Adjust themes in RSS Feed Router
- Add custom RSS sources
- Customize personal story patterns

---

**Need Help?** 
- Check main README.md for detailed documentation
- Review troubleshooting section
- LinkedIn: [john-onyekachi](https://www.linkedin.com/in/john-onyekachi)
