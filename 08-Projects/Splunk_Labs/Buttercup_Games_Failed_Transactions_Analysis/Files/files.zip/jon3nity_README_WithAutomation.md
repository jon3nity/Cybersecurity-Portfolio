# Hi, I'm John Onyekachi 👋

**MSc Cybersecurity Student | Aspiring SOC Analyst | Azure Certified | Automation Engineer**

Computer Engineering graduate pursuing MSc in Cybersecurity at Atlantic Technological University, Letterkenny. Passionate about threat detection, vulnerability management, security compliance, and workflow automation. Currently building a professional portfolio while working towards industry certifications.

📍 Based in Letterkenny, Ireland  
🎓 Graduating September 2026 with Distinction focus  
🎯 Seeking SOC Analyst / Security Analyst roles in Ireland

---

## 🚀 Current Focus

**Certification Journey (Week 2/11):**
- ✅ **Microsoft Azure Fundamentals (AZ-900)** - Certified January 2026
- 🔄 **Splunk Core Certified User** - In Progress
- 📅 **CompTIA Security+** - Q1 2026
- 📅 **CompTIA Network+** - Q1 2026

**Portfolio Projects:**
- 🛡️ ISO 27001 ISMS Implementation (Financial Services)
- 🏥 GDPR Healthcare Compliance Assessment
- 📊 NIST 800-30 Risk Assessment (University Financial System)
- 🔍 Data Center Vulnerability Assessment & CVE Analysis
- 🤖 LinkedIn Automation System (n8n + Claude AI + Multi-API Integration)

---

## 💼 Technical Skills

**Security Operations:**
- Vulnerability Management & CVE Research
- SIEM (Splunk) & Log Analysis
- Network Security (Cisco, Fortinet)
- Wireshark Packet Analysis

**Compliance & Governance:**
- ISO 27001, GDPR, NIST SP 800-30
- Risk Assessment & Treatment Planning
- Policy Development & Audit Preparation

**Automation & Integration:**
- n8n Workflow Automation
- API Integration (Google, LinkedIn, Slack, Anthropic)
- Claude AI Integration (Sonnet 4)
- Docker Containerization
- Multi-source Data Aggregation
- Event-Driven Architectures

**Infrastructure:**
- Networking: IPv4 Subnetting, OSPF, VLANs, Routing
- Cloud: Microsoft Azure (AZ-900 Certified)
- Systems: Windows Server, Ubuntu Linux
- Containers: Docker, Docker Compose

**Tools & Technologies:**
- CVSS Scoring & Prioritization
- Cisco Packet Tracer
- n8n Workflow Engine
- Network Configuration & Security
- Documentation & Technical Writing

---

## 📂 Featured Projects

### [CyberSecurity-MSc-Portfolio](https://github.com/jon3nity/CyberSecurity-MSc-Portfolio)
Comprehensive portfolio documenting my MSc journey with hands-on projects across:
- **Compliance & Governance:** ISO 27001, GDPR, NIST frameworks
- **Vulnerability Management:** Data center assessment, CVE analysis
- **Network Security:** Campus design, VLAN security, routing protocols
- **Security Operations:** Splunk SIEM, Wireshark analysis

### [LinkedIn Automation System](https://github.com/jon3nity/linkedin-automation-n8n)
Production-grade workflow automation system featuring:
- Multi-source content aggregation (RSS, Gmail, Google Calendar)
- Claude AI integration for natural language generation
- Intelligent personal story mining from email
- Theme-based content routing
- Quality gates and relevance scoring
- Automated image selection (Unsplash API)
- Multi-platform publishing (LinkedIn, Sheets, Slack)
- 100% success rate, $0/month operating cost

---

## 🌐 Connect With Me

[![LinkedIn](https://img.shields.io/badge/LinkedIn-%230077B5.svg?logo=linkedin&logoColor=white)](https://www.linkedin.com/in/john-onyekachi) [![Email](https://img.shields.io/badge/Email-D14836?logo=gmail&logoColor=white)](mailto:jon3nity.oj@gmail.com) [![Portfolio](https://img.shields.io/badge/Portfolio-000000?logo=github&logoColor=white)](https://github.com/jon3nity/CyberSecurity-MSc-Portfolio)

---

## 🛠️ Tech Stack

**Security & Networking:**  
![Wireshark](https://img.shields.io/badge/Wireshark-1679A7?style=for-the-badge&logo=wireshark&logoColor=white)
![Splunk](https://img.shields.io/badge/Splunk-000000?style=for-the-badge&logo=splunk&logoColor=white)
![Cisco](https://img.shields.io/badge/Cisco-049fd9?style=for-the-badge&logo=cisco&logoColor=white)

**Cloud & Infrastructure:**  
![Azure](https://img.shields.io/badge/Azure-0078D4?style=for-the-badge&logo=microsoftazure&logoColor=white)
![AWS](https://img.shields.io/badge/AWS-%23FF9900.svg?style=for-the-badge&logo=amazon-aws&logoColor=white)
![Linux](https://img.shields.io/badge/Linux-FCC624?style=for-the-badge&logo=linux&logoColor=black)
![Docker](https://img.shields.io/badge/Docker-2496ED?style=for-the-badge&logo=docker&logoColor=white)

**Automation & AI:**  
![n8n](https://img.shields.io/badge/n8n-EA4B71?style=for-the-badge&logo=n8n&logoColor=white)
![Claude AI](https://img.shields.io/badge/Claude_AI-000000?style=for-the-badge&logo=anthropic&logoColor=white)

**Development & Automation:**  
![Python](https://img.shields.io/badge/python-3670A0?style=for-the-badge&logo=python&logoColor=ffdd54)
![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)
![Git](https://img.shields.io/badge/git-%23F05033.svg?style=for-the-badge&logo=git&logoColor=white)
![GitHub](https://img.shields.io/badge/github-%23121011.svg?style=for-the-badge&logo=github&logoColor=white)

---

## 📊 GitHub Stats

![](https://github-readme-stats.vercel.app/api?username=jon3nity&theme=chartreuse-dark&hide_border=false&include_all_commits=true&count_private=false)<br/>
![](https://nirzak-streak-stats.vercel.app/?user=jon3nity&theme=chartreuse-dark&hide_border=false)<br/>
![](https://github-readme-stats.vercel.app/api/top-langs/?username=jon3nity&theme=chartreuse-dark&hide_border=false&include_all_commits=true&count_private=false&layout=compact)

---

## 🎯 Career Objectives

**Target Roles:** SOC Analyst, Security Analyst, Junior Security Engineer, Automation Engineer  
**Target Companies:** Ward Solutions, Integrity360, Version 1, Accenture (Ireland)  
**Salary Range:** €35,000 - €55,000  
**Immigration Pathway:** Stamp 2 (student) → Stamp 1G → Critical Skills Employment Permit

**What I Bring:**
- Hands-on experience with vulnerability assessments and compliance frameworks
- Proven automation engineering skills (production LinkedIn automation system)
- Strong analytical thinking and attention to detail
- API integration and workflow orchestration expertise
- Systematic approach to problem-solving
- "No quitter" mentality when facing technical challenges
- Passion for continuous learning and professional development

---

## 📈 Learning Journey

**Completed:**
- ✅ AZ-900: Microsoft Azure Fundamentals (January 2026)
- ✅ Production n8n Workflow Automation (LinkedIn system with 9 API integrations)
- ✅ IPv4 Subnetting Mastery (0% → 100% accuracy)
- ✅ Campus Network Design (3,220-device architecture)
- ✅ ISO 27001 ISMS Implementation
- ✅ GDPR Healthcare Compliance Assessment
- ✅ NIST 800-30 Risk Assessment
- ✅ Data Center Vulnerability Assessment

**In Progress:**
- 🔄 Splunk Core Certified User
- 🔄 CompTIA Security+ Preparation
- 🔄 Network+ Certification Study

**Upcoming:**
- 📅 TryHackMe Practical Labs
- 📅 Home Lab Setup (Security Operations)
- 📅 Advanced n8n Workflows (Multi-platform automation)

---

## 🤖 Automation Portfolio Highlights

**LinkedIn Content System:**
- 9 API integrations (Google Calendar, Gmail, LinkedIn, Slack, Anthropic, Unsplash)
- Real-time personal achievement mining from Gmail
- Theme-based content routing (5 daily themes)
- AI-powered content generation (Claude Sonnet 4)
- Intelligent image selection and matching
- Multi-platform analytics (Sheets, Slack notifications)
- Production status: 100% success rate, $0/month cost

**Technical Achievements:**
- Event-driven architecture with fallback strategies
- Multi-source data aggregation and scoring
- Quality gates with trusted source overrides
- Comprehensive error handling and retry logic
- Docker containerization for deployment

---

[![](https://visitcount.itsvg.in/api?id=jon3nity&icon=5&color=13)](https://visitcount.itsvg.in)

<!-- Updated: January 2026 | MSc Cybersecurity @ ATU Letterkenny -->
